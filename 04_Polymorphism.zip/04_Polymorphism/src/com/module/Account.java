package com.module;

public abstract class Account {
	private String name;
	protected double balance;
	protected int accno;
	protected double amount;
public Account()
{
	
}
public Account(int accno,String name,double balance)
{
	this.accno=accno;
	this.name=name;
	this.balance=balance;
	
}
public String toString()
{
	String str;
	str="Account no :"+accno+"\t"+"Name :"+name+"\t"+"Balance: "+balance;
	return str;
}
public abstract void withdraw(double amount);


}
