package com.module;

public class Recuring extends Savingaccount{
	private int installment;
	public Recuring()
	{
		
	}
	public Recuring(int accno,String name,double balance,String address,double amount,int installment)
	{
		super( accno, name, balance, address,amount);
		
		this.installment=installment;
		
	}
	 public String toString()
	 {
	 	String str;
	 	
	 	str=super.toString()+"Installment: "+installment;
	 	return str;
	 }
	 public void withdraw(double amount)
	 {
		// balance=balance;
		 System.out.println("withdrwal not possible");
		 System.out.println("The net balance is:");
		 System.out.println(+balance);
	 }
	 
}
